import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Инициализация Supabase
  await Supabase.initialize(
    url: 'https://your-project-id.supabase.co',  // Замените на свой URL
    anonKey: 'your-anon-key',  // Замените на свой анонимный ключ
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Приложение с Supabase',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  bool _checkboxValue = false;
  int _radioValue = 1;
  final TextEditingController _textController = TextEditingController();

  // Функция для сохранения данных в базу данных Supabase
  Future<void> saveData() async {
    final supabase = Supabase.instance.client;
    final response = await supabase.from('your_table').insert([
      {'column1': _textController.text, 'column2': _checkboxValue ? 'True' : 'False'},
    ]).execute();

    if (response.error == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Данные успешно сохранены')));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка: ${response.error!.message}')));
    }
  }

  // Функция для получения данных из базы данных Supabase
  Future<void> fetchData() async {
    final supabase = Supabase.instance.client;
    final response = await supabase.from('your_table').select().execute();

    if (response.error == null) {
      print('Данные: ${response.data}');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка при получении данных')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Приложение с Supabase'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Привет, Flutter
