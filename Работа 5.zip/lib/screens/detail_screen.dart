import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget {
  final String data;

  DetailScreen({required this.data});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Детали')),
      body: Center(
        child: Text('Переданные данные: $data', style: TextStyle(fontSize: 20)),
      ),
    );
  }
}


