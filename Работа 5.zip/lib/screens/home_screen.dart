import 'package:flutter/material.dart';
import 'list_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isChecked = false;
  String _selectedRadio = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Главный экран')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Привет, Flutter!', style: TextStyle(fontSize: 24)),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context)
                    .showSnackBar(SnackBar(content: Text('Нажата кнопка!')));
              },
              child: Text('Нажми меня'),
            ),
            SizedBox(height: 16),
            IconButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Нажата кнопка с иконкой!')));
              },
              icon: Icon(Icons.thumb_up),
            ),
            SizedBox(height: 16),
            CheckboxListTile(
              title: Text('Checkbox'),
              value: _isChecked,
              onChanged: (bool? value) {
                setState(() {
                  _isChecked = value ?? false;
                });
              },
            ),
            ListTile(
              title: Text('Option 1'),
              leading: Radio<String>(
                value: 'Option 1',
                groupValue: _selectedRadio,
                onChanged: (String? value) {
                  setState(() {
                    _selectedRadio = value ?? '';
                  });
                },
              ),
            ),
            ListTile(
              title: Text('Option 2'),
              leading: Radio<String>(
                value: 'Option 2',
                groupValue: _selectedRadio,
                onChanged: (String? value) {
                  setState(() {
                    _selectedRadio = value ?? '';
                  });
                },
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ListScreen()),
                );
              },
              child: Text('Перейти к спискам'),
            ),
          ],
        ),
      ),
    );
  }
}
