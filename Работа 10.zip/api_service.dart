import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'https://jsonplaceholder.typicode.com';

  Future<List<Map<String, dynamic>>> fetchTasks() async {
    final response = await http.get(Uri.parse('$baseUrl/todos'));
    if (response.statusCode == 200) {
      List<dynamic> data = jsonDecode(response.body);
      return data.map((task) => {
        'id': task['id'],
        'title': task['title'],
        'isDone': task['completed'] ? 1 : 0,
      }).toList();
    } else {
      throw Exception('Failed to load tasks');
    }
  }

  Future<void> addTask(String title) async {
    final response = await http.post(
      Uri.parse('$baseUrl/todos'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'title': title,
        'completed': false,
      }),
    );
    if (response.statusCode != 201) {
      throw Exception('Failed to add task');
    }
  }
}
