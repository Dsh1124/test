import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(MyApp());
}

class Counter with ChangeNotifier {
  int _counter = 0;

  int get counter => _counter;

  void increment() {
    _counter++;
    notifyListeners(); // Уведомляем всех слушателей об изменении состояния
  }

  void decrement() {
    if (_counter > 0) {
      _counter--;
      notifyListeners();
    }
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => Counter(),
      child: MaterialApp(
        home: Scaffold(
          appBar: AppBar(
            title: Text('Flutter Counter with Provider'),
          ),
          body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                // Отображаем значение счетчика
                Consumer<Counter>(
                  builder: (context, counter, child) {
                    return Text(
                      'Counter: ${counter.counter}',
                      style: TextStyle(fontSize: 30),
                    );
                  },
                ),
                SizedBox(height: 20),
                // Кнопки для увеличения и уменьшения счетчика
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    ElevatedButton(
                      onPressed: () {
                        // Увеличиваем счетчик
                        Provider.of<Counter>(context, listen: false).increment();
                      },
                      child: Text('Increment'),
                    ),
                    SizedBox(width: 20),
                    ElevatedButton(
                      onPressed: () {
                        // Уменьшаем счетчик
                        Provider.of<Counter>(context, listen: false).decrement();
                      },
                      child: Text('Decrement'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
