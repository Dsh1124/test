import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Инициализация Firebase
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Firebase Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  bool isChecked = false;
  int radioValue = 0;
  TextEditingController textController = TextEditingController();

  // Функция для сохранения данных в Firebase
  Future<void> saveData() async {
    await FirebaseFirestore.instance.collection('users').add({
      'name': textController.text,
      'isChecked': isChecked,
      'radioValue': radioValue,
    });
  }

  // Функция для получения данных из Firebase
  Stream<QuerySnapshot> getData() {
    return FirebaseFirestore.instance.collection('users').snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Flutter Firebase Demo'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: textController,
              decoration: InputDecoration(labelText: 'Enter Name'),
            ),
            Row(
              children: [
                Text('Checkbox: '),
                Checkbox(
                  value: isChecked,
                  onChanged: (bool? newValue) {
                    setState(() {
                      isChecked = newValue!;
                    });
                  },
                ),
              ],
            ),
            Row(
              children: [
                Text('Radio 1: '),
                Radio(
                  value: 0,
                  groupValue: radioValue,
                  onChanged: (int? value) {
                    setState(() {
                      radioValue = value!;
                    });
                  },
                ),
                Text('Radio 2: '),
                Radio(
                  value: 1,
                  groupValue: radioValue,
                  onChanged: (int? value) {
                    setState(() {
                      radioValue = value!;
                    });
                  },
                ),
              ],
            ),
            ElevatedButton(
              onPressed: saveData,
              child: Text('Save Data'),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: getData(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(child: CircularProgressIndicator());
                  }
                  var data = snapshot.data!.docs;
                  return ListView.builder(
                    itemCount: data.length,
                    itemBuilder: (context, index) {
                      var doc = data[index];
                      return ListTile(
                        title: Text(doc['name']),
                        subtitle: Text('Checkbox: ${doc['isChecked']}, Radio: ${doc['radioValue']}'),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
